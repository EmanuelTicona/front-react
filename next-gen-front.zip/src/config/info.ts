/*  
    Aquí se almacenan los archivos de configuración de la aplicación, 
    como las variables de entorno, las configuraciones de enrutamiento, 
    las configuraciones de bibliotecas externas, etc.
*/