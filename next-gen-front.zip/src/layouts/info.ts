/*  
    Aquí se encuentran los componentes que definen la estructura general 
    de las páginas, como el encabezado, el pie de página, la barra 
    lateral, etc.
*/