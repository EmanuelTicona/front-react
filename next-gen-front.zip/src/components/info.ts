/*  
    Esta carpeta contiene componentes reutilizables que son específicos 
    de la interfaz de usuario (UI), como botones, tarjetas, encabezados, 
    barras de navegación, etc. Estos componentes renderizan elementos 
    visuales y pueden tener estilos y lógica asociada.
*/