/*  
    Esta carpeta contiene los hooks personalizados que se utilizan 
    en la aplicación. Los hooks personalizados son funciones que 
    encapsulan lógica reutilizable y pueden compartirse entre
    diferentes componentes.
*/