/*  
    Aquí se colocan las funciones auxiliares que no están 
    directamente relacionadas con la lógica de la aplicación, 
    como funciones de formato, validación, manipulación de cadenas, etc.
*/