/*  
    Esta carpeta contiene los proveedores y consumidores de contexto 
    de React, que se utilizan para compartir datos entre componentes 
    sin necesidad de pasarlos a través de props.
*/