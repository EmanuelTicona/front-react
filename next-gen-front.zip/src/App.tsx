import { AppRouter } from "./router";
export const App = () => {
  return (<AppRouter />)
}
