export const API_URL = 'http://127.0.0.1:5000/'; // Local
//export const API_URL = 'https://lvlsub9c7b.execute-api.us-east-2.amazonaws.com/dev/'; 
