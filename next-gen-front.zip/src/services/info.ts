/*  
    Aquí se encuentran las funciones o clases que se encargan de 
    la comunicación con APIs externas, servicios de backend o cualquier 
    otra lógica de negocio relacionada con la obtención y manipulación 
    de datos.
*/