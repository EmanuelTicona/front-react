/*  
    En esta carpeta se colocan todas las consultas y mutaciones 
    relacionadas con React Query, que se utilizan para obtener 
    y actualizar datos de una API o cualquier otra fuente de datos.
*/