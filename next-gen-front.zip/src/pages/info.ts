/*  
    Esta carpeta contiene los componentes que representan las diferentes 
    vistas o páginas de la aplicación, como la página de inicio, la página 
    de detalles de producto, la página de carrito de compras, etc.
*/