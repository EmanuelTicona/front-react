/*  
    Aquí se definen los tipos personalizados de TypeScript que se utilizan 
    en la aplicación, como interfaces, enumeraciones, tipos de utilidad, etc.
*/