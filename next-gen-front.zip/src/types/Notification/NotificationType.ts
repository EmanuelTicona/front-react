import { AlertColor } from '@mui/material';

export type NotificationType = {
    msg: string;
    color: string;
    severity: AlertColor;
  };
  